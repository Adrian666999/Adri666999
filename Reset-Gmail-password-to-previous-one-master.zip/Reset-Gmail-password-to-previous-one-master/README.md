# Reset-Gmail-password-to-previous-one
This script changes Google password 100 times and then resets the one that was set previous

1.  Install missing DLLs with the exe.
    If you are afraid of virus just download it from official webpage at https://www.autoitscript.com/site/autoit/downloads/
    
2.  Edit VBS file so that your email and password are correct.

3.  Logout of all you Google accounts in Chrome.

4.  Open command prompt and navigate to place where you saved the VBS and run "cscript passwordresetscript.vbs".

5.  Wait a couple minutes and voila! You have you old password!

**DISCLAIMER:** this is not completely my project. This is only an improved version with AutoIT setup exe

**ORIGINAL VERSION:** <https://gist.github.com/bjarki/9886887>
